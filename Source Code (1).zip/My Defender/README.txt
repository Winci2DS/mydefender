Put this folder in C:\Users\Your Name\source\repos (excluding this file) and start editing*

*only for visual studio users